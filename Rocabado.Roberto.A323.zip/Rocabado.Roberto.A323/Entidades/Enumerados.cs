﻿public enum EGrupo
{
    CALL_IN,
    CALL_OUT,
    RRSS
}
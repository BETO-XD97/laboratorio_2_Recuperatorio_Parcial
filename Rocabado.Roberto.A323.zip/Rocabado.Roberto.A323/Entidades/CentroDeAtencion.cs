﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class CentroDeAtencion
    {
        private int cantRacsPorSuper;
        private List<Empleado> empleados;
        private string nombre;

        public CentroDeAtencion(string nombre, int cantRacsPorSuper)
        {
            this.nombre = nombre;
            this.cantRacsPorSuper = cantRacsPorSuper;
            this.empleados = new List<Empleado>();
        }

        public List<Empleado> Empleados
        {
            get { return this.empleados; }
        }

        public string Nombre
        {
            get { return this.nombre; }
        }

        public string ImprimirNomina()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Nombre: {this.Nombre}\n");
            if(this.empleados is not null)
            {
                foreach (var item in this.Empleados)
                {
                    sb.AppendLine(item.ToString());
                }
            }

            return sb.ToString();
        }

        private bool ValidaCantidadDeRacs()
        {
            int contSupervisores = 0;
            int contRacs = 0;
            int cantRacsPermitido = 5;

            foreach (var item in this.Empleados)
            {
                if (item is Rac)
                {
                    contRacs++;
                }
                else if (item is Supervisor)
                {
                    contSupervisores++;
                }
            }

            if(contRacs != 0 && contSupervisores != 0)
            {
                if ((contRacs / contSupervisores) == cantRacsPermitido)
                {
                    cantRacsPermitido += 5;
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else { return true; }

        }

        public static bool operator ==(CentroDeAtencion c, Empleado e)
        {
            if(c.Empleados is not null && e is not null)
            {
                foreach(var item in c.Empleados)
                {
                    if(item == e)
                    {
                        return true;   
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            return false;
        }

        public static bool operator !=(CentroDeAtencion c, Empleado e)
        {
            return !(c == e);
        }

        public static bool operator +(CentroDeAtencion c, Empleado e)
        {
            if(c.Empleados is not null && e is not null)
            {
                if(c != e)
                {
                    if (e is Supervisor)
                    {

                        if (c.ValidaCantidadDeRacs())
                        {
                            c.Empleados.Add(e);
                            return true;
                        }
                    }
                    else if (e is Rac)
                    {
                        c.Empleados.Add(e);
                        return true;
                    }
                }
            }

            return false;
        }

        public static string operator -(CentroDeAtencion c, Empleado e)
        {

            string rtn = "";
            if (c.Empleados is not null && e is not null)
            {
                if(c != e)
                {
                    rtn = "Empleado No Encontrado";           
                }
                else
                {
                    e.HoraEgreso = DateTime.Now.TimeOfDay;
                    rtn = e.EmitirFactura();
                    c.Empleados.Remove(e);
                }
               
            }
                return rtn;
        }
    }
}

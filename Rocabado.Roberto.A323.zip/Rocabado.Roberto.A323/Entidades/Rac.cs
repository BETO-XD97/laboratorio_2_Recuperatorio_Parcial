﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Rac : Empleado
    {
        private EGrupo grupo;
        private static double valorHora;

        static Rac()
        {
            valorHora = 875.90F;
        }

        public Rac(string legajo, string nombre, TimeSpan horaIngreso)
            : base(legajo, nombre, horaIngreso)
        {
            this.grupo = EGrupo.CALL_IN;
        }

        public Rac(string legajo, string nombre, TimeSpan horaIngreso, EGrupo grupo)
            : base(legajo, nombre, horaIngreso)
        {
            this.grupo = grupo;
        }

        public static double ValorHora
        {
            get { return valorHora; } 
            set 
            {
                if(value > 0)
                {
                    valorHora = value;
                } 
            }
        }

        public EGrupo Grupo
        {
            get { return this.grupo; }
        }

        public override string EmitirFactura()
        {
            return $"Factura de: {this.ToString()}\nImporte a facturar: {base.Facturar()}";
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} - {this.grupo.ToString()} - {base.Legajo} - {base.Nombre}";
        }

        private double CalculaBonoDeGrupo()
        {

            if(this.Grupo is EGrupo.RRSS)
            {
                return 0.2;
            }
            else if (this.Grupo is EGrupo.CALL_OUT)
            {
                return 0.1;
            }
            else 
            {
                return 0;
            }

        }

        protected new double Facturar()
        {
            return (ValorHora * (1 + CalculaBonoDeGrupo())) * base.Facturar(); 
        }


    }
}

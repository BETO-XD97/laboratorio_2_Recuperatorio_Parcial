﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Empleado
    {
        protected TimeSpan horaEgreso;
        protected TimeSpan horaIngreso;
        protected string legajo;
        protected string nombre;

        protected Empleado(string legajo, string nombre, TimeSpan horaIngreso)
        {
            this.legajo = legajo;
            this.nombre = nombre;
            this.horaIngreso = horaIngreso;
        }

        public TimeSpan HoraEgreso
        {
            get { return this.horaEgreso; }
            set { this.HoraEgreso = ValidaHoraEgreso(value); }
        }

        public TimeSpan HoraIngreso
        {
            get { return this.horaIngreso; }
        }

        public string Legajo
        {
            get { return this.legajo; }
        }

        public string Nombre
        {
            get { return this.nombre; }
        }

        private TimeSpan ValidaHoraEgreso(TimeSpan horaEgreso) 
        {
            if(horaEgreso > HoraIngreso)
            {
                return horaEgreso;
            }
            else
            {
                return DateTime.Now.TimeOfDay;
            }
        }

        protected double Facturar()
        {
            double rtn = 0;

            rtn = (HoraEgreso - HoraIngreso).TotalHours;

            return rtn;
        }

        public abstract string EmitirFactura();

        public static bool operator ==(Empleado emp1, Empleado emp2)
        {
            if(emp1 is not null && emp2 is not null)
            {
                if (emp1.Legajo == emp2.Legajo)
                {
                  return true;
                }
            }

            return false;
        }

        public static bool operator !=(Empleado emp1, Empleado emp2)
        {
            return !(emp1 == emp2);
        }
    }
}
